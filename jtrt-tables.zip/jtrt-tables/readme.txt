=== JTRT Responsive Tables ===
Contributors: MyThirdEye
Donate link: //
Tags: responsive tables, responsive, table, table generator, csv to table, csv, convert csv, responsive table generator, foo tables, responsive table, mobile tables, awesome table generator
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Designed to help users easily create responsive tables in the backend without having to read or write code. This plugin converts CSV files into responsive HTML.

== Description ==

JTRT Responsive Tables is a plugin designed to help average wordpress users with creating great responsive tables for their websites. This plugin makes use of Foo Tables engenius scripts to create elegant yet functional responsive tables. This plugin however goes a step beyond Foo Tables by allowing users to manually select which columns they want to hide in real time instead of having to deal with HTML and CSS. 

== Installation ==

1. Upload `jtrt-tables folder` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enjoy

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Changelog ==

= 1.2 =
* Added A Tabbed menu layout for the back-end.

== Arbitrary section ==

This plugin makes use of Foo Tables to create the responsiveness of the tables. 
